<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Find out more about our subscription plans | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Billing</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Billing</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">How long is the free trial?</a>
                     </li>
                     <li>
                        <a href="#tab2">What happens when the free trial ends?</a>
                     </li>
                     <li>
                        <a href="#tab3">Will I receive reminders before I need to renew my subscription?</a>
                     </li>  
                                      
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                       
                     <li>
                        <a href="#tab4">Who can renew the account subscription?                        </a>
                     </li>
                     <li>
                        <a href="#tab5">What happens when I do not renew my subscription?</a>
                     </li>                  
                  </ul>
               </div>
              
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">How long is the free trial?</h2>
            <p>The free trial is for a period of 100 days.</p>
           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">What happens when the free trial ends?</h2>
             
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/pricing-bill.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                         <p>Once the free trial ends, you have the option to buy a subscription.  If you choose not to, then the account is deactivated. You have the choice to reactivate it anytime you login.  However, dormant accounts cannot be reactivated after a period of one year.</p>
                        
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/pricing-bill.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">Will I receive reminders before I need to renew my subscription?</h2>
            <p>Yes, we let you know several times prior to the renewal of your subscription. You can buy a new subscription anytime during your free trial period and up to 30 days prior to the renewal of your subscription.</p>
           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">Who can renew the account subscription?</h2>
            <p>Any user with Admin privileges can renew the account subscription.</p>
             
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5" style="box-shadow: none">
         <div class="container">
            <h2 class="mb-4">What happens when I do not renew my subscription?</h2>
            <p>When you buy a subscripton for the first time, auto-renewal is activated. When it is time to renew it, we send you notifications on the renewal. When your subscription expires, it gets automatically renewed. If the credit card has changed or expired and the subscription is not renewed, you will receive a noticifcaiton on failed renewal, after which you can renew your subscription manually.</p>
            
            
         </div>
      </section>
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class=" pt-4 pb-4 bottomsection" style="background: #fff;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="event-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/mail.svg" class="img-fluid mt-3 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Event Management </h3>
                           <p>Manage all your events seamlessly.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="dashboard.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/dashboard.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Dashboard</h3>
                           <p>Navigate through your array of dashboards.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="speaker-engage-basic.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/comment.svg" class="img-fluid mt-3 mb-4 mb-md-0 ">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Engage Basics</h3>
                           <p>Know your way around the fundamentals of Speaker Engage. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays" >
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  