<?php

?>


<html>
  <head>
    <title>reCAPTCHA demo: Explicit render after an onload callback</title>
      <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  
    <script type="text/javascript">
      var onloadCallback = function() {
        grecaptcha.render('html_element', {
          'sitekey' : '6LcOmu0UAAAAAAuyPO6ioiCU4Rz_BLxxLP1oQmbi'
        });
      };
    </script>
  </head>
  <body>
    <form action="?" id="testform" method="POST">
      <div id="html_element"></div>
      <br>
      <input type="submit" value="Submit">
    </form>
    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
    </script>

    <script type="text/javascript">
    	
    $( "#testform" ).submit(function( event ) { 

        event.preventDefault();  

        var resp = grecaptcha.getResponse();

        if(resp.length){
          grecaptcha.reset();
          alert("ready to submit");
        }else{
          alert("not ready");      

            }


      });  

    	 /*var rcres = grecaptcha.getResponse();
          if(rcres.length){
            grecaptcha.reset();
            showHideMsg("Form Submitted!","success");
          }else{
            showHideMsg("Please verify reCAPTCHA","error");
          }*/
    </script>


  </body>
</html>