<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Engage in quick and easy communication with all your contacts | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Master Communication</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Master Communication</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">How can I ask for missing information from the members in the Master List?</a>
                     </li>
                     <li>
                        <a href="#tab2">Can I send emails to individual contacts in the Master List?</a>
                     </li>
                     <li>
                        <a href="#tab3">How can I manage all the emails sent to each contact in the Master List?</a>
                     </li> 
                      <li>
                        <a href="#tab4">How do I know if a contact in the Master List opened my emails?                        </a>
                     </li>                   
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                    
                     <li>
                        <a href="#tab5">Can I add special comments about each contact in the Master List?</a>
                     </li>
                     <li>
                        <a href="#tab6">Is there  a one page summary of each contact?</a>
                     </li>
                     <li>
                        <a href="#tab7">Can I send emails to all contacts in the Master List at a time?</a>
                     </li>                    
                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">How can I ask for missing information from the members in the Master List?</h2>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="add-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-member.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">It's good to have as much information from the supporters, volunteers, and others on the Master List. To request for additional or missing information, you can follow these steps:</p>
                        <p>Step 1: Click on the 'Request' icon against the contacts in the ‘Manage Masters’ section. A pop-up dialogue box appears.</p>
                       
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="add-user11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-member1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">"Step 2: In the pop-up box, you can choose to request specific information from the drop down menu. Select the fields for which you want information from this contact.</p>
                        <p>You have the option of scheduling the email at a certain day/date or sending the request immediately. There is also a field where you can personalize the request. Once you send the request, the contact receives an email with a link. The link leads to a web page where they can update the information, which is automatically stored."</p>
                     </div>
                  </div>
               </div>
               
               
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="add-user1" data-toggle="tab" href="#add-user1" role="tab" aria-controls="add-user1" aria-selected="true"> <img src="images/master-member.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="add-user11" data-toggle="tab" href="#add-user11" role="tab" aria-controls="add-user11" aria-selected="true"> <img src="images/master-member1.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                 
                  
               </ul> 
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">Can I send emails to individual contacts in the Master List?</h2>
            
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/individual.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">                        
                          <p class="tags1">Yes, you can. You can send personalized messages to individual contacts in the Master List. Follow these steps:</p>
                          <p>Step 1: Click on the 'Bell' icon (labeled 'Notify') against contacts in the ‘Manage Master’ section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="manage-user11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/individual1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                          <p class="tags1">Step 2: Select the options in various fieds and for ‘Email Subject' and ‘CC Email Addresses’. You can select an email template from the available templates which allows you to quickly leverage existing content in the system. Once you have edited the content, you can send the email right away or schedule it to be sent.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/individual.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="manage-user11" data-toggle="tab" href="#manage-user11" role="tab" aria-controls="manage-user11" aria-selected="true"> <img src="images/individual1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">How can I manage all the emails sent to each contact in the Master List?</h2>
            
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/contact-master-list.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                       <p  class="tags1">It is important to know how your emails as being received. To learn the status of emails sent to each contact in the Master List, follow these steps:</p>
                       <p>Step 1: In the ‘Manage Masters’ section, there is a column titled ‘Emails Sent’.</p>
                       
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="plan1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/contact-master-list1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p  class="tags1">Step 2: Under this column, you can click on the ‘Preview’ button against a contact and view all the emails sent to them. It also displays the satuts of the emails, whether they've been opened or not.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/contact-master-list.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#plan1" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/contact-master-list1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">How do I know if a contact in the Master List opened my emails?</h2>
           
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/opened-master-list1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p  class="tags1">Step 1: In the ‘Manage Masters’ section, there is a column titled ‘Emails Sent’. Under this column, you can click on the ‘Preview’ button.</p>
                        
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="change-plans" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/opened-master-list1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                        <p  class="tags1">Step 2: You can view the date on which the emails were sent and whether the contact has opened them or not.</p>
                      
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab5" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="change-plan11" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="change-plan11" aria-selected="true"> <img src="images/opened-master-list.jpg" class="img-fluid" width="100"></a>
                  </li>
                   <li class="nav-item">
                     <a class="nav-link " id="change-plans" data-toggle="tab" href="#change-plans" role="tab" aria-controls="change-plans" aria-selected="true"> <img src="images/opened-master-list1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">Can I add special comments about each contact in the Master List?</h2>
               
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/speacial-comment.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                        <p>You can edit a contact's profile and add special comments in the form of 'Notes'. Click on the 'Edit' button against each contact and a form opens up. You can scroll down to the box titled 'Notes'. Enter the special comments about this contact and save. This allows all the team members to be on the same page to ensure proper engagement.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history1" data-toggle="tab" href="#track-history1" role="tab" aria-controls="track-history1" aria-selected="true"> <img src="images/speacial-comment.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6">
         <div class="container">
            <h2 class="mb-4">Is there  a one page summary of each contact?</h2>
           <p>There is no one-page summary of each contact.</p>
        
         </div>
      </section> 
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab7" style="box-shadow: none">
         <div class="container">
            <h2 class="mb-4">Can I send emails to all contacts in the Master List at a time?</h2>
           
         <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                         <p>Yes, you can. In the drop-down under ‘Masters’, click on ‘Bulk Notify’. Here you can select the name or the master type you would want the bulk e-mail to reach. Select a template that matches your requirement and add a subject line.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history2" data-toggle="tab" href="#track-history2" role="tab" aria-controls="track-history2" aria-selected="true"> <img src="images/master-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
         </div>
      </section>   
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection" style="box-shadow: none">
         <div class="container">
            <div class="row">
              <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="resource-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/resource.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Resource Management</h3>
                           <p>Aggregate and store all assets and resources related to an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Communication</h3>
                           <p>Engage in quick and easy communication with your sponsors.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="speaker-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0 " width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Communication</h3>
                           <p>Engage in quick and easy communication with your speakers. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays">
                  <a href="master-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Management</h3>
                           <p>Manage all the contacts you need for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">// ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  