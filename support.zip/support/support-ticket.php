<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Create Support Ticket | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
         ul.question-list li {
    list-style: none;
    margin-bottom: 15px;
}
.cid-rH31kyJShk .box {
    background-image: url(../assets/images/background1.jpg);
    background-size: cover;
    background-position: center;
    height: 350px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
}.cid-rH31kyJShk .box {
    background-image: url(../images/video-thump.jpg) !important;
}
button.close{    position: absolute;    right: 10px;    top: 10px;    color: #fff;}
.nav-item:first-child .nav-link{text-decoration: underline; font-weight: bold;}
.modal-content{background: none; border: 0;}
.support_request{
   padding-top: 55px;
   padding-bottom: 45px;
   background: linear-gradient(45deg, #f9f9f9, #f9f9f9);
}
.support_request h2{
	font-size: 2.2rem;
}
#myModal .modal-dialog{
	background-color: #fff;
}
#myModal .modal-header{
	justify-content: center;
}
#myModal button.close {
    background-color: #E91E63;
    opacity: 1;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    line-height: 0px;
    text-align: center;
    justify-content: center;
    display: flex;
	color: #fff;
}
button.close span {
    position: relative;
    top: -3px;
}
.btn-center{
	display: flex;
	justify-content: center;
}
.support_request .form-control{
    background-color: #fff;
    border: 1px solid;
	padding-left: 15px;
	line-height: initial;
}

.subject textarea{
	max-height: 50px;
}
p.question{
	font-size: 18px;
}
.btn-center .btn-primary{
	padding: 6px 30px;
}
.support_request .mbr-section-btn .btn-primary{
	padding: 15px 25px;
}
.hideoption { display:none; visibility:hidden; height:0; font-size:0; }
h3.mbr-fonts-style{
	line-height:20px;
}
#myModal .modal-body{
	height: 100%;
}
.modal-dialog, .modal-content{
	height: auto;
}
.support_request::before, .support_request::after {
    content: "";
    display: none;
    width: 400px;
    background-size: 400px 445px;
    background-repeat: no-repeat;
    position: absolute;
    top: 0;
    bottom: 0;
    right: auto;
    height: auto;
    background-color: transparent;
    z-index: 1;
	top: -13px;
}

.errorcls{
	background-color: #fce4e4 !important;
  border: 1px solid #cc0033 !important;
  outline: none !important;
}




@media (min-width: 768px){
	.support_request::before, .support_request::after {
		display: block;
	}
}	
@media only screen and (min-width:1200px){
	.support_request::after{
		right: 71%;
		background-image: url(./images/intro-left.svg);
		background-position: top right;
	}
	.support_request::before{
		left: 71%;
		background-image: url(./images/intro-right.svg);
		background-position: top left;
	}
}
@media only screen and (min-width:992px) and (max-width: 1199px) {
	.support_request::after{
		right: 72%;
		background-image: url(./images/intro-left.svg);
		background-position: top right;
	}
	.support_request::before{
		left: 72%;
		background-image: url(./images/intro-right.svg);
		background-position: top left;
	}
}
@media only screen and (min-width:768px) and (max-width:991px) {
	.support_request::after{
		right: 73%;
		background-image: url(./images/intro-left.svg);
		background-position: top right;
	}
	.support_request::before{
		left: 73%;
		background-image: url(./images/intro-right.svg);
		background-position: top left;
	}
}
      </style>
   </head>
   <body>
      <?php echo landing_header(); ?>
       
		<section class="support_request">
			<div class="container">
				<div class="support-content">
					<div class="support-header">
						<h5 class="modal-title display-5 text-center pb-3 pb-lg-4">Open a Support Request</h5>
					</div>
					<div class="col-sm-12 col-md-7 col-lg-6 col-xl-5 mx-auto">
						<p class="question text-center">What is your question about?</p>
						
						<div class="form-group">
							<div class="row">
								<div class="col-sm-12">
									<select class="custom-select form-control inpcls" name="support_category" id="support_category">
										<option selected disabled class="hideoption" value="">Select a Category</option>
										<option value="Speaker Engage Basics">Speaker Engage Basics</option>
										<option value="Account Management">Account Management</option>
										<option value="Dashboards">Dashboards</option>
										<option value="Event Management">Event Management</option>
										<option value="Speaker Mangement">Speaker Mangement</option>
										<option value="Speaker Communication">Speaker Communication</option>
										<option value="Sponsor Management">Sponsor Management</option>
										<option value="Master Management">Master Management</option>
										<option value="Master Communication">Master Communication</option>
										<option value="Action Tracker">Action Tracker</option>
										<option value="Notification Engine">Notification Engine</option>
										<option value="Resource Management">Resource Management</option>
										<option value="Billing">Billing</option>
									</select>
								</div>
							</div>
							<h3 class="pt-2 mbr-fonts-style plan-subtitle align-left mbr-light display-4 text-center">
								Please select the most relevant category. This will help us provide you with the best support possible.
							</h3>
						</div>	
						<div class="form-group">	
							<div class="row">
								<div class="col-sm-12 subject">
									<input type="text" name="subject" placeholder="Subject*" data-form-field="text" class="form-control display-7 inpcls" value="" id="support_subject">
								</div>
							</div>
						</div>	
						<div class="form-group">	
							<div class="row">
								<div class="col-sm-12">
									<textarea type="text" class="form-control inpcls" placeholder="Description*" name="description" id="support_description" style="min-height: 120px;"></textarea>
								</div>
							</div>
						</div>	
						<div class="form-group">
							<div class="row">
								<div class="col-sm-12">		
									<input type="number" name="contactno" placeholder="Phone Number" data-form-field="text" class="form-control display-7 inpcls" value="" id="support_phone">
								</div>
							</div>	
						</div>
						<div class="form-group">
							<div class="row">
								<div class="col-sm-12">		
									<input type="email" name="Email" placeholder="Email address*" data-form-field="Email" class="form-control display-7 inpcls" value="" id="support_email" required="required">
								</div>
							</div>	
						</div>

						<div id="html_element" class="inpcls"></div>
      
						<div class="form-group">
							<div class="row btn-center">
								<div class="col-auto">
									<button type="button"  class="btn btn-primary display-7" id="send">SEND</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	
		</section>
		

	

      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
      <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
    </script>
      <script type="text/javascript">

      	 var onloadCallback = function() {
        grecaptcha.render('html_element', {
          'sitekey' : '6LcOmu0UAAAAAAuyPO6ioiCU4Rz_BLxxLP1oQmbi'
        });
      };

         function lightbox_open() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  window.scrollTo(0, 0);
  document.getElementById('light').style.display = 'block';
  document.getElementById('fade').style.display = 'block';
  lightBoxVideo.play();
}

function lightbox_close() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  document.getElementById('light').style.display = 'none';
  document.getElementById('fade').style.display = 'none';
  lightBoxVideo.pause();
}

//***************************************************************************//

$("#send").click(function() {
	$(".inpcls").removeClass('errorcls');
  var support_category = $( "#support_category option:selected" ).val();
  var support_subject = $("#support_subject").val();
  var support_description = $("#support_description").val();
  var support_phone = $("#support_phone").val();
  var support_email = $("#support_email").val();

  var is_cat_error = is_subject_error = is_desc_error = is_email_error = 0;
  
  if(support_category == ''){
  	is_cat_error = 1;
  	$("#support_category").addClass('errorcls');
  }

  if(support_subject == ''){
  	is_subject_error = 1;
  	$("#support_subject").addClass('errorcls');
  }

  if(support_description == ''){
  	is_desc_error = 1;
  	$("#support_description").addClass('errorcls');
  }

  if(support_email == ''){
  	is_email_error = 1;
  	$("#support_email").addClass('errorcls');
  }

  if(is_cat_error != 1 && is_subject_error != 1 && is_desc_error != 1 && is_email_error != 1){

  	var resp = grecaptcha.getResponse();

        if(resp.length){

		  	$.ajax({
		               type: "POST",
		               url: "support-ticket-ajax.php",               
		               data: {"support_category" : support_category, "support_subject":support_subject, "support_description":support_description, "support_email":support_email,"support_phone":support_phone },
		               // dataType: "json",
		               success: function(data) { 
		                
		               	if(data == 'success')
		               	{
		               		Swal.fire({
		                                    type: 'success',
		                                    title: 'Success',
		                                    text: 'Thank you. We have received your question and our support team will contact you within 24 business hours',
		                                    allowOutsideClick: false
		                                  }).then(okay => {
		                                       if (okay) {
		                                         location.reload();
		                                      }
		                                    });
		               	}

		                
		               }
		          }); 

 		 }else{
 		 	$("#html_element").addClass('errorcls');
 		 }
  }



});



  </script>
   </body>
</html>