<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Engage in quick and easy communication with your sponsors | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Sponsor Communication</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Sponsor Communication</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">How can I ask for missing information from sponsors?</a>
                     </li>
                     <li>
                        <a href="#tab2">Can I send emails to individual sponsors?</a>
                     </li>
                     <li>
                        <a href="#tab3">How can I manage all the emails sent to each sponsor?</a>
                     </li>   
                     <li>
                        <a href="#tab4">How do I know if a sponsor opened my emails?
                        </a>
                     </li>
                     <li>
                        <a href="#tab5">How do I receive content from sponsors?</a>
                     </li>                 
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                     
                     <li>
                        <a href="#tab6">Can I add special comments about each sponsor?</a>
                     </li>   
                        <li>
                        <a href="#tab7">Is there  a one page summary of each sponsor?</a>
                     </li>
                     <li>
                        <a href="#tab8">Can a sponsor be associated with multiple sponsorships?</a>
                     </li>
                     <li>
                        <a href="#tab9">Can I send emails to all sponsors at a time?</a>
                     </li> 

                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">How can I ask for missing information from sponsors?</h2>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="add-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/missing-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">You can request for additional information from a sponsor easily.  Follow these three steps.</p>
                        <p>Step 1: Click on the 'Request' icon against the speaker names in the ‘Manage Sponsors’ section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/missing-sponsor1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p  class="tags1">Step 2: In the pop-up dialogue box that comes up, you can choose to request for missing information or missing documentation. Select the fields that are relevant and appropriate (check boxes or edit request content) </p>
                       <p>Step 3: You can send the request right away or schedule it to be sent later. This triggers an email to the sponsor with the message and a link for them to update the information. Once they update the information, it is automatically saved to their record.</p>
                     </div>
                  </div>
               </div>
             
              
                
             
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="add-user1" data-toggle="tab" href="#add-user1" role="tab" aria-controls="add-user1" aria-selected="true"> <img src="images/missing-sponsor.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="add-user2" data-toggle="tab" href="#add-user2" role="tab" aria-controls="add-user2" aria-selected="false"><img src="images/missing-sponsor1.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">Can I send emails to individual sponsors?</h2>
            
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/email-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Yes, you can. You can send personalized messages to individual sponsors. Follow these steps:</p>
                        <p>Step 1: Click on the 'Bell' icon (labeled 'Notify') against the sponsor names in the ‘Manage Sponsors’ section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="manage-user11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/email-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Step 2: Select the options in various fields and for ‘Email Subject' and ‘CC Email Addresses’. You can choose to send a copy to the 'Executive Sponsor'. You can select an email template from the available templates; these allow you to quickly leverage existing content in the system. Once you have edited the content, you can send the email right away or schedule it to be sent.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/email-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="manage-user11" data-toggle="tab" href="#manage-user11" role="tab" aria-controls="manage-user11" aria-selected="true"> <img src="images/email-sponsor1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">How can I manage all the emails sent to each sponsor?</h2>
           
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">You can view the status of all communication sent to each sponsor so that you can make decisions on contacting them and engaging them.  Follow these steps:</p>
                        <p>Step 1: In the ‘Manage Sponsors’ section, there is a column titled ‘Emails sent’./p> </p>
                     </div>
                  </div>
               </div>
                 <div class="tab-pane masonry-container	" id="plan1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email-sponsor1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Step 2: Under this column, you can click on the ‘Preview’ button against a sponsor and view all the emails sent to them. In the pop-up dialogue box, you will be shown all the emails that were sent and when and if they were opened or not.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/manage-email-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#plan1" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/manage-email-sponsor1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">How do I know if a sponsor opened my emails?</h2>
            
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p class="tags11">Step 1: In the ‘Manage Sponsors’ section, there is a column titled ‘Emails sent’. Under this column, you can click on the ‘Preview’ button.</p>
                      
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email-sponsor1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p class="tags11">Step 2: You can view the date on which the emails were sent and if the sponsor has opened them or not.</p>
                      
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab5" role="tablist">
                 <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#change-plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/manage-email-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/manage-email-sponsor1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">How do I receive content from sponsors?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/recive-content-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p>There are two ways for sponsor content can be uploaded.</p>
                      <p>1: You can add the information when you create a sponsor. You can later edit it as well.</p>
                      <p>2. You can request content from the sponsor as well which automatically is stored in the sponsor record information. You can learn how to request for content from the sponsor from previous questions.</p>
                     </div>
                  </div>
               </div>
           
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history1" data-toggle="tab" href="#track-history1" role="tab" aria-controls="track-history1" aria-selected="true"> <img src="images/recive-content-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6">
         <div class="container">
            <h2 class="mb-4">Can I add special comments about each sponsor?</h2>
            <p>Yes, you can, in the 'Notes' field at the bottom of the page where you edit the sponsor information. Here you can enter comments about the sponsor. The note entered here can be viewed by clicking the ‘View’ icon against the specific sponsor.</p>
        
         </div>
      </section>   
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab7">
         <div class="container">
            <h2 class="mb-4">Is there  a one page summary of each sponsor?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-histor10" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/summary-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p>Yes. You can access the one page summary of the sponsor information with the 'View' button (eye symbol). This makes it allows you to view the information in a concise manner, making it easy to navigate and identify gaps.</p>
                     </div>
                  </div>
               </div>
                
               
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-histor10" data-toggle="tab" href="#track-histor10" role="tab" aria-controls="track-histor10" aria-selected="true"> <img src="images/summary-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab8">
         <div class="container">
            <h2 class="mb-4">Can a sponsor be associated with multiple sponsorships?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="multiple-sessions1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sponsor-type.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p>Yes, they can. You can associate a sponsor to multiple sponsorships through the 'Sponsor Type' field. A dropdown appears when you click on the box associated to sponsor type. You can select all the sponsorships that the sponsor has committed to by clicking the check boxes. This will automatically count towards the revenue and also reduce the inventory of the available sponsorships so that sponsorships are not oversubscribed.</p>
                     </div>
                  </div>
               </div>
               
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="multiple-sessions1" data-toggle="tab" href="#multiple-sessions1" role="tab" aria-controls="multiple-sessions1" aria-selected="true"> <img src="images/sponsor-type.jpg" class="img-fluid" width="100"></a>
                  </li>                
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab9" style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">Can I send emails to all sponsors at a time?</h2>
           <p>Yes, you can. In the drop-down under ‘Sponsors’, click on ‘Bulk Notify’.</p>
           <p>Here you can choose to send bulk emails to certain set of sponsors.  To do that, select the sponsor type you would want the bulk email to be sent to. You can also select sponsors according to their status. Then select the email template that you want to use, make changes to the content as needed and send the email now or schedule it for later.  Once you send the email you can also view the open rates in the sponsor dashboard to see engagement.</p>
           
            
         </div>
      </section>
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection"  style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Management</h3>
                           <p>Manage all your sponsors for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="master-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0 "  width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Communication</h3>
                           <p>Engage in quick and easy communication with all your contacts.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays" >
                  <a href="master-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Management</h3>
                           <p>Manage all the contacts you need for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
       <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  