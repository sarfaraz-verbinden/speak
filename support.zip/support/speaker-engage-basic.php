<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="learn how to navigate through your Speaker Engage Account, create events, add users, add speakers, manage speakers, add sponsors, manage sponsors and so much more.">
      <title>Speaker Engage Basics | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Speaker Engage Basics</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Speaker Engage Basics</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#speakerEngage">What is Speaker Engage?</a>
                     </li>
                     <li>
                        <a href="#helpEventmanagement">How does Speaker Engage help with my event management?</a>
                     </li>
                     <li>
                        <a href="#createAccount">How do I create an account on Speaker Engage?</a>
                     </li>
                     <li>
                        <a href="#organization">What is the Organization Name field and how do I choose the correct name?</a>
                     </li>
                     <li>
                        <a href="#subscriptions">What levels of subscriptions are available for Speaker Engage?</a>
                     </li>
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#lostDetails">How do I manage lost username and password for my account?
                        </a>
                     </li>
                     <li>
                        <a href="#freeTrail">How long is the free trial period and what features are enabled?</a>
                     </li>
                     <li>
                        <a href="#otherAccount">Can I create other users for my account?</a>
                     </li>
                     <li>
                        <a href="#multipleEvent">Can I manage multiple events on my account?</a>
                     </li>
                     <li>
                        <a href="#createEvent">How do I get started with creating an event?</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4"  id="speakerEngage">
         <div class="container">
            <h2 class="mb-4">What is Speaker Engage?</h2>
            <div class="row">
               <div class="col-md-12">
                  <p>Speaker Engage is a fully-integrated, cloud-based platform with speaker, sponsor, and community curation. The platform has a centralized content management system powered by seamless workflow automation that helps organizers remove the chaos from event planning and execution.</p>
               </div>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="helpEventmanagement">
         <div class="container">
            <h2 class="mb-4">How does Speaker Engage help with my event management?</h2>
            <div class="row">
               <div class="col-md-12">
                  <p>Speaker Engage is first and foremost an organizational tool that allows planners to manage their speakers, sponsors, and event resources.  Speaker Engage consolidates event planning tasks, speaker and sponsor curation, and communications.  It also has action and resource tracker functions so that planners can view their to-do lists and incorporate all relevant event documents within the platform. Communications with speakers and sponsors are also managed through the platform.  Speaker Engage makes it easy to manage your events with efficient modern workflow management.</p>
               </div>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="createAccount">
         <div class="container">
            <h2 class="mb-4">How do I create an account on Speaker Engage?</h2>
            <!-- tab content starts here -->
            <div class="tab-content " id="myTabContent">
               
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="create-account" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/create-account.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags">Creating an account on Speaker Engage is easy and all accounts begin with a 100-day risk-free trial. Go to <a href="https://speakerengage.com/" target="_blank">speakerengage.com</a> and click on sign up for free.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="create-account1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/create-account1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags">This will take you to a login page. Click on the ‘Free Trial’ button.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="create-account2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/create-account2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags">Fill in the required details.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="create-account3" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/create-account3.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags">You can verify your email ID and set your password. You are now ready to plan and execute your events.</p>
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="create-account" data-toggle="tab" href="#create-account" role="tab" aria-controls="create-account" aria-selected="true"> <img src="images/create-account.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="create-account1" data-toggle="tab" href="#create-account1" role="tab" aria-controls="create-account1" aria-selected="false"><img src="images/create-account1.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="create-account2" data-toggle="tab" href="#create-account2" role="tab" aria-controls="create-account2" aria-selected="false"><img src="images/create-account2.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="create-account3" data-toggle="tab" href="#create-account3" role="tab" aria-controls="create-account3" aria-selected="false"><img src="images/create-account3.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="organization">
         <div class="container">
            <h2 class="mb-4">What is the Organization Name field and how do I choose the correct name?</h2>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="org-name" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/org-name.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                         <p>The Organization Name field is where you enter the name of the organization you represent. This field is used to create public pages where speakers, sponsors, and others interact. This helps in clear branding. The public URL pages will have this format: https://speakerenage.com/organizationname/pagename.  So choose wisely since this can not be changed.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="org-name" data-toggle="tab" href="#org-name" role="tab" aria-controls="org-name" aria-selected="true"> <img src="images/org-name.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="subscriptions">
         <div class="container">
            <h2 class="mb-4">What levels of subscriptions are available for Speaker Engage</h2>
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/plan.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p>There are three levels of subscription available after the 100 day free trial - Essential, Professional, and Premier. Each one has specific limits and you can upgrade or downgrade at any time. Notifications are also sent if certain limits are reached.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/plan.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="lostDetails">
         <div class="container">
            <h2 class="mb-4">How do I manage lost username and password for my account?</h2>
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="reset-password" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/reset-password.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">If you forget your username or password, it can be easily reset. Click on the ‘Forgot Password’ link on the login screen. </p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="reset-password1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/reset-password1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">Enter your registered email address and reset your password. You will receive a link to your email address to set your new password. Don’t forget to check your spam/junk folders if you do not receive the reset email before requesting a new reset email link.</p>
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab5" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="reset-password" data-toggle="tab" href="#reset-password" role="tab" aria-controls="create-account" aria-selected="true"> <img src="images/reset-password.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="reset-password1" data-toggle="tab" href="#reset-password1" role="tab" aria-controls="reset-password1" aria-selected="false"><img src="images/reset-password1.jpg" class="img-fluid" width="100"></a>
                  </li>
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="freeTrail">
         <div class="container">
            <h2 class="mb-4">How long is the free trial period and what features are enabled?</h2>
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="free" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/free.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p>The free trial we offer is for 100 days. It gives you access to the Essential plan and all the features associated with it.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="free" data-toggle="tab" href="#free" role="tab" aria-controls="free" aria-selected="true"> <img src="images/free.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="otherAccount">
         <div class="container">
            <h2 class="mb-4">Can I create other users for my account?</h2>
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="other-account" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/other-account.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11 ">Yes, you can.   You can create multiple users on your account and there is no limit.  In addition, you can create users with different roles which automatically gives them access to select information of your events/account. Once the account is created, the creator is given admin privilages by default. This includes the rights to create additional users. You can access this feature in the ‘My Account’ section.</p>
                        <p>Click on the ‘My Account’ section. It is on the upper right corner of the screen.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="other-account1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/other-account1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Click on ‘Add User’.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="other-account2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/other-account2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Fill in the required details and click on ‘Create’. This user gets added to the list in the previous screen. </p>
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab7" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="other-account" data-toggle="tab" href="#other-account" role="tab" aria-controls="other-account" aria-selected="true"> <img src="images/other-account.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="reset-password1" data-toggle="tab" href="#other-account1" role="tab" aria-controls="other-account1" aria-selected="false"><img src="images/other-account1.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="reset-password1" data-toggle="tab" href="#other-account2" role="tab" aria-controls="other-account2" aria-selected="false"><img src="images/other-account2.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="multipleEvent">
         <div class="container">
            <h2 class="mb-4">Can I manage multiple events on my account?</h2>
            <div class="tab-content" id="myTabContent6">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="multiple-event" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-event.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                         <p>Speaker Engage comes with the facility to create and manage multiple events at the same time. The account home page lists all the current events. You can toggle to view all the past events. This allows you to manage multiple events in one place while helping you access information from past events.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab8" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="multiple-event" data-toggle="tab" href="#multiple-event" role="tab" aria-controls="multiple-event" aria-selected="true"> <img src="images/multiple-event.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E bg-white pt-4 pb-4" id="createEvent">
         <div class="container">
            <h2 class="mb-4">How do I get started with creating an event?</h2>
            <div class="tab-content" id="myTabContent7">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="start" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/start.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">In the account dashboard, click on the button ‘Create New Event’.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="start1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/start1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Fill in the details of the event, such as event name, date, location, time zone, etc. Don’t forget to save the details. All the scheduled emails will follow the time zone you have set while creating the event. Be advised that the time zone cannot be modified/edited later.</p>
                        <p>Once the event is created, you will be able to access the event related information and mange your event.</p>
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab9" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="start" data-toggle="tab" href="#start" role="tab" aria-controls="start" aria-selected="true"> <img src="images/start.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="start1" data-toggle="tab" href="#start1" role="tab" aria-controls="start1" aria-selected="false"><img src="images/start1.jpg" class="img-fluid" width="100"></a>
                  </li>
               </ul>
            </div>
         </div>
      </section>
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection" style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="account-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/account.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Account Management</h3>
                           <p>Here’s how you can manage your accounts.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="dashboard.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/dashboard.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Dashboard</h3>
                           <p>Navigate through your array of dashboards.</p>
                        </div>
                     </div>
                  </a>
               </div>
               
               <div class="col-md-6 p-4 bg-grays1">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/networking.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays"  style="">
                  <a href="event-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/mail.svg" class="img-fluid mt-2 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Event Management</h3>
                           <p>Manage all your events seamlessly.</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>