<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Manage all the contacts you need for an event | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Master Management</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Master Management</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">What is this Master List and why do I need it?</a>
                     </li>
                     <li>
                        <a href="#tab2">What is the sign-up form for Master List?</a>
                     </li>
                     <li>
                        <a href="#tab3">Can I create new contacts in the Master List?</a>
                     </li>  
                      <li>
                        <a href="#tab4">Can I create custom categories in the Master List?
                        </a>
                     </li>                  
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                    
                     <li>
                        <a href="#tab5">Can a contact in the Master List be associated with multiple roles?</a>
                     </li>
                     <li>
                        <a href="#tab6">Is there a dashboard where I can get a quick update on the status of the Master List?
</a>
                     </li>                    
                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">What is this Master List and why do I need it?</h2>
            <p>The Master List helps event organizers (other than speakers and sponsors) communicate with other flawlessly. TThey could be volunteers, executives, influencers, attendees, or supporters in the community. You can organize all these contacts in various lists and communicate with them individually or collectively through Speaker Engage.</p>           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">What is the sign-up form for Master List?</h2>
             <p>The Master sign-up form is a public landing page with a unique URL, which  you can share publicly, allowing anyone to sign up as a volunteer, influencer, or supporter. They can select the role they want to be involved as. This gives the event organizer an easy way to solicit and invite people to be associated with the event.</p>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">Can I create new contacts in the Master List?</h2>
           
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-list1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Yes, you can. You can create individual contacts on this list by following these steps: </p>
                        <p>Step 1: Click on 'Create New' from the 'Manage Masters' section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="plan1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-list2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p  class="tags11">Step 2: Click on 'Create New' from the pop-up.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="plan2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-list3.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Step 3: Fill in the mandatory fields and other necessary information and save. This will add the contact to the Master List. Once this step is complete,  you can communicate and engage with these contacts.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/master-list1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#plan1" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/master-list2.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan2" data-toggle="tab" href="#plan2" role="tab" aria-controls="plan2" aria-selected="true"> <img src="images/master-list3.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">Can I create custom categories in the Master List?</h2>
          
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-type-settings.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                         <p >Yes, you can. There are default categories when you create a new event: Sponsor, Attendee, Volunteer, Speaker, Community, Executive and Other. To create a new category, click on 'Create New Master Type', fill in the type of category you would like in your Master List and save. Now this category will be available in the sign-up form as well.</p>
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs d-none d-md-block" id="myTab5" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="change-plan11" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="change-plan11" aria-selected="true"> <img src="images/master-type-settings.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">Can a contact in the Master List be associated with multiple roles?</h2>
            
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-type.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p>Yes, each contact in the Master List can be associated with multiple roles. Next to every contact is a column titled 'Type', which displays the role of the contact. You can check additional boxes to include a contact into those categories. Associating each contact with multiple categories makes communication with each category type easy; every contact in that list gets the relevant information easily.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history1" data-toggle="tab" href="#track-history1" role="tab" aria-controls="track-history1" aria-selected="true"> <img src="images/master-type.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6" style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">Is there a dashboard where I can get a quick update on the status of the Master List?</h2>
            
         <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/masterdashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p>Yes, from the Master Dashboard in the 'Dashboards' tab or in the 'Event Home' tab. The Master Dashboard gives a summary of the status and an overview of all the actions taken in the Master List for an event. The dashboard displays information such as total contacts, total emails sent, and total emails opened. You can also see the number of contacts in each category, and recent communications sent with open rates and profile gap.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history2" data-toggle="tab" href="#track-history2" role="tab" aria-controls="track-history2" aria-selected="true"> <img src="images/masterdashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
         </div>
      </section>   
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection" style="box-shadow: none;">
         <div class="container">
            <div class="row">
              <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. 
</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Management</h3>
                           <p>Manage all your sponsors for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="master-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0 "  width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Communication</h3>
                           <p>Engage in quick and easy communication with all your contacts.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays">
                  <a href="billing.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/bill.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Billing</h3>
                           <p>Find out more about our subscription plans.</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  