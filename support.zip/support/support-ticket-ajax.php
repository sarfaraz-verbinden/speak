<?php


if($_POST['support_subject'] != ''){


	$support_category = $_POST['support_category'];
	$support_subject = $_POST['support_subject'];
	$support_description = $_POST['support_description'];
	$support_email = $_POST['support_email'];
	$support_phone = $_POST['support_phone'];

	$subject = "Speaker Engage Support Ticket";
	$to_email = "support@speakerengage.com";
	$from_email = "notify@speakerengage.com";   
	$body = 'Hi There,<br/><br/>

	A new support ticket has been submitted.<br/><br/>
	Please find the details: <br/>
	<span><b>Category</b></span>: '.$support_category.' <br/>
	<span><b>Subject</b></span>: '.$support_subject.' <br/>
	<span><b>Description</b></span>: '.$support_description.' <br/>
	<span><b>Email address</b></span>: '.$support_email.' <br/>
	<span><b>Contact</b></span>: '.$support_phone.' <br/>
	';



	$trigger_email = sendEmail($to_email,$from_email,$subject,$body);
            
	echo 'success';
}


function sendEmail($to, $from, $subject, $body, $fromName=null, $cc_mails=null){
        
        $url = 'https://api.sendgrid.com/';
         $user = 'Meylahcorp';
         $pass = 'Em@ils19!';

        $json_string = array(

          'to' =>$to,
          'category' => 'test_category'
        );

        /*if(empty($from)){
            $from = "support@speakerengage.com";
        }*/
        
        $fromName = "Speaker Engage Team";
        
        $params = array(
        'api_user'  => $user,
        'api_key'   => $pass,
        'to'        => $to,
        'subject'   => $subject,
        'html'      => $body,
        'text'      => "",
        'from'      => $from,
        'fromname'  => $fromName,
        'replyto'   => $from,   
      );
          

        $request =  $url.'api/mail.send.json';

        // Generate curl request
        $session = curl_init($request);
        // Tell curl to use HTTP POST
        curl_setopt ($session, CURLOPT_POST, true);
        // Tell curl that this is the body of the POST
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        // Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        // obtain response
        $response = curl_exec($session);
        curl_close($session);
        // print everything out
        //print_r($response);exit;
    }













?>