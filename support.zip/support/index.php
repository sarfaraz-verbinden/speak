<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Help & Support | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
         ul.question-list li {
    list-style: none;
    margin-bottom: 15px;
}
.cid-rH31kyJShk .box {
    background-image: url(../assets/images/background1.jpg);
    background-size: cover;
    background-position: center;
    height: 350px;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: center;
}.cid-rH31kyJShk .box {
    background-image: url(../images/video-thump.jpg) !important;
}
button.close{    position: absolute;    right: 10px;    top: 10px;    color: #fff;}
.nav-item:first-child .nav-link{text-decoration: underline; font-weight: bold;}
.modal-content{background: none; border: 0;}
.support_request{
   padding-top: 55px;
   padding-bottom: 45px;
   background: linear-gradient(45deg, #f9f9f9, #f9f9f9);
}
.support_request h2{
	font-size: 2.2rem;
}
#myModal .modal-dialog{
	background-color: #fff;
}
#myModal .modal-header{
	justify-content: center;
}
#myModal button.close {
    background-color: #E91E63;
    opacity: 1;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    line-height: 0px;
    text-align: center;
    justify-content: center;
    display: flex;
	color: #fff;
}
button.close span {
    position: relative;
    top: -3px;
}
.btn-center{
	display: flex;
	justify-content: center;
}
#myModal .form-control{
    background-color: #fff;
    border: 1px solid;
}
#myModal .modal-dialog{
	border-radius: 5px;
}
.subject textarea{
	max-height: 50px;
}
p.question{
	font-size: 18px;
}
.btn-center .btn-primary{
	padding: 6px 30px;
}
.support_request .mbr-section-btn .btn-primary{
	padding: 15px 25px;
}
.hideoption { display:none; visibility:hidden; height:0; font-size:0; }
h3.mbr-fonts-style{
	line-height:20px;
}
#myModal .modal-body{
	height: 100%;
}
.modal-dialog, .modal-content{
	height: auto;
}
@media only screen and (min-width:1200px){
	#myModal .modal-body{
		padding: 15px 35px 35px 35px;
		height: 100%;
	}
}
      </style>
   </head>
   <body>
      <?php echo landing_header(); 
       echo support_header();?>
       <section class="bg-blues p-4">
         <div class="container">
            <div class="col-lg-8 m-auto">
            <form class="mb-0">
               <div class="row mb-0">
                  <div class="col-md-12 mb-lg-0">
               <input class="form-control mr-sm-2 cus-search mb-lg-0" type="search" placeholder="How to add to the list of resources?" aria-label="Search" style="font-style: italic;;">
                <button class="btn btn-default cus-search-btn mb-lg-0" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
           
  </div>
            </form>
         </div>
         </div>
       </section>
    
      <section class="cid-rHBCmoWF1E fshadow " style="box-shadow: none;">
         <div class="container">
            
           
            <div class="row">
               <div class="col-lg-8">
                  <h1 class="mbr-bold ml-lg-5 pl-lg-3 mb-2 txt-cent">Get Started</h1>
            <div class="row">
               <div class="col-lg-12 ">
                 <img src="images/start-button.svg" class="img-fluid float-left mr-3 mt-2 mt-md-0" width="50px">
                 <div class="float-left wd-80">
                  <p class="mb-0">New to Speaker Engage? </p>
                  <p>Learn the basics and get started!</p>
               </div>
              </div>
               
           </div>
                  <div class="cid-rH31kyJShk" id="video02-q" style="padding-bottom: 0!important">  
                     <div class="box">
                 <div class="mbr-media show-modal align-center py-2" data-toggle="modal" data-target="#exampleModalCentered" onclick="lightbox_open();">
                    <div class="icon-wrap">
                        <span class="mbr-iconfont mobi-mbri-play mobi-mbri"></span>
                    </div>
                </div>
            </div>
               </div>
           </div>
               <div class="col-lg-4">
                  <div class="bg-gray p-4">
                     <h3 class="mb-4 fnt-1">Common Support Questions</h3>
                  <ul class="question-list mb-0">
                     <li>
                        <a href="speaker-engage-basic.php#createAccount">How do I create an account on Speaker Engage?
                        </a>
                     </li>
                     <li>
                        <a href="event-management.php#tab1">How do I create a new event in my account?</a>
                     </li>
                     <li>
                        <a href="sponsor-management.php#tab2">How can I add new sponsors to my list?</a>
                     </li>
                     <li>
                        <a href="speaker.php#tab1">Can I add speakers to my list one at a time?</a>
                     </li>
                     <li>
                        <a href="billing.php#tab2">What happens when the FREE Trial ends?</a>
                     </li>
                  </ul>
              </div>
               </div>
            </div>
         </div>
      </section>
     
      
    
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Browse by Category</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bw-cat" style="box-shadow: none;">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="speaker-engage-basic.php">
                      <img src="images/comment.svg" class="img-fluid mb-4">
                        <h3>Speaker Engage Basics</h3>
                        <p>Know your way around the fundamentals of Speaker Engage.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="account-management.php">
                       <img src="images/account.svg" class="img-fluid mb-4">
                        <h3>Account Management</h3>
                        <p>Here’s how you can manage your accounts.  </p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="dashboard.php">
                       <img src="images/dashboard.svg" class="img-fluid mb-4">
                        <h3>Dashboards</h3>
                        <p>Navigate through your array of dashboards.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="event-management.php">
                       <img src="images/calendar.svg" class="img-fluid mb-4"  >
                        <h3>Event Management</h3>
                        <p>Manage all your events seamlessly.</p>
                        
                  </a>
               </div>
               
              
                <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="speaker.php">
                     <img src="images/speaker.svg" class="img-fluid mb-4"> 
                                            <h3>Speaker Mangement</h3>
                        <p>Manage your growing list of speakers for an event. </p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="speaker-communication.php">
                     <img src="images/speaker-communication.svg" class="img-fluid mb-4"> 
                                            <h3>Speaker Communication</h3>
                        <p>Engage in quick and easy communication with your speakers.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="sponsor-management.php">
                        <img src="images/sponsor.svg" class="img-fluid mb-4">
                        <h3>Sponsor Management</h3>
                        <p>Manage all your sponsors for an event.</p>
                        
                  </a>
               </div>
                <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="sponsor-communication.php">
                        <img src="images/sponsor-communication.svg" class="img-fluid mb-4">
                        <h3>Sponsor Communication</h3>
                        <p>Engage in quick and easy communication with your sponsors.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="master-management.php">
                        <img src="images/master.svg" class="img-fluid mb-4">
                        <h3>Master Management</h3>
                        <p>Manage all the contacts you need for an event.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="master-communication.php">
                       <img src="images/master-communication.svg" class="img-fluid mb-4">
                        <h3>Master Communication</h3>
                        <p>Engage in quick and easy communication with all your contacts.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="action-tracker.php">
                       <img src="images/action.svg" class="img-fluid mb-4">
                        <h3>Action Tracker</h3>
                        <p>Track your actions and manage your events more efficiently.</p>
                        
                  </a>
               </div>
                 <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="notification-engine.php">
                       <img src="images/notification-engine.svg" class="img-fluid mb-4">
                        <h3>Notification Engine</h3>
                        <p>Get a glimpse of everything you will be notified on.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center d-none d-lg-block" ></div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="resource-management.php">
                     
                       <img src="images/resource.svg" class="img-fluid mb-4">
                        <h3>Resource Management</h3>
                        <p>Aggregate and store all assets and resources related to an event.</p>
                        
                  </a>
               </div>
               <div class="col-md-4 col-lg-3 p-4 align-center" >
                  <a href="billing.php">
                   
                       <img src="images/bill.svg" class="img-fluid mb-4">
                        <h3>Billing</h3>
                        <p>Find out more about our subscription plans.</p>
                        
                  </a>
               </div>
             <div class="col-md-4 col-lg-3 p-4 align-center d-none d-lg-block" ></div>
               </div>
            </div>
         </div>
      </section>
		<section class="support_request">
			<h2 class="mbr-fonts-style mbr-section-title align-center mbr-light display-2">
				Did not find an answer to your question from our help and support section?
			</h2>
			<div class="mbr-section-btn text-center">
				<a href="support-ticket.php" class="btn btn-lg btn-primary"  class="btn btn-primary display-4">Create Support Ticket</a>
			</div>
		</section>
		
<!-- Modal HTML -->
<div id="myModal" class="modal fade " tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title display-5">Open a Support Request</h5>
				<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
			</div>
			<div class="modal-body">
				<p class="question">What is your question about?</p>
				
				<div class="form-group">
					<div class="row">
						<div class="col-sm-12">
							<select class="custom-select1 form-control">
								<option selected disabled class="hideoption">Select a Category</option>
								<option>Speaker Engage Basics</option>
								<option>Account Management</option>
								<option>Dashboards</option>
								<option>Event Management</option>
								<option>Speaker Mangement</option>
								<option>Speaker Communication</option>
								<option>Sponsor Management</option>
								<option>Master Management</option>
								<option>Master Communication</option>
								<option>Action Tracker</option>
								<option>Notification Engine</option>
								<option>Resource Management</option>
								<option>Billing</option>
							</select>
						</div>
					</div>
					<h3 class="pt-2 mbr-fonts-style plan-subtitle align-left mbr-light display-4">
						Please select the most relevant category. This will help us provide you with the best support possible.
					</h3>
				</div>	
				<div class="form-group">	
					<div class="row">
						<div class="col-sm-12 subject">
							<input type="text" name="subject" placeholder="Subject*" data-form-field="text" class="form-control display-7" value="" id="phone">
						</div>
					</div>
				</div>	
				<div class="form-group">	
					<div class="row">
						<div class="col-sm-12">
							<textarea type="text" class="form-control" placeholder="Description*" name="description" style="min-height: 120px;"></textarea>
						</div>
					</div>
				</div>	
				<div class="form-group">
					<div class="row">
						<div class="col-sm-12">		
							<input type="number" name="contactno" placeholder="Phone Number" data-form-field="text" class="form-control display-7" value="" id="phone">
						</div>
					</div>	
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-sm-12">		
							<input type="email" name="Email" placeholder="Email address*" data-form-field="Email" class="form-control display-7" value="" id="Email_address" required="required">
						</div>
					</div>	
				</div>
				<div class="form-group">
					<div class="row btn-center">
						<div class="col-auto">
							<button type="button" data-dismiss="modal" class="btn btn-primary display-7" id="send">SEND</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	
      <!-- Modal -->
<div class="modal fade" id="exampleModalCentered" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenteredLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-dialog-centered" role="document" style="max-width: 800px !important;">
    <div class="modal-content" style="height: auto;">
      <div class="modal-body" style="padding: 0px;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="lightbox_close();">
          <span aria-hidden="true" class="mbri-close mbr-iconfont closeModal"></span>

        </button>
        <div id="light">
          <a class="boxclose" id="boxclose" onclick="lightbox_close();"></a>
          <video id="VisaChipCardVideo" width="100%" controls>
              <source src="../images/Speaker-Engage-Explainer-Video-V3.mp4" type="video/mp4">
              <!--Browser does not support <video> tag -->
            </video>
        </div>
      </div>
      
    </div>
  </div>
</div>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         function lightbox_open() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  window.scrollTo(0, 0);
  document.getElementById('light').style.display = 'block';
  document.getElementById('fade').style.display = 'block';
  lightBoxVideo.play();
}

function lightbox_close() {
  var lightBoxVideo = document.getElementById("VisaChipCardVideo");
  document.getElementById('light').style.display = 'none';
  document.getElementById('fade').style.display = 'none';
  lightBoxVideo.pause();
}


  </script>
   </body>
</html>