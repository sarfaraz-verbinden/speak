<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Engage in quick and easy communication with your speakers | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Speaker Communication</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Speaker Communication</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">How can I ask for missing information from speakers?</a>
                     </li>
                     <li>
                        <a href="#tab2">Can I send emails to individial speakers?</a>
                     </li>
                     <li>
                        <a href="#tab3">How can I manage all the emails sent to each speaker?</a>
                     </li>   
                     <li>
                        <a href="#tab4">How do I know if a speaker opened my emails?
                        </a>
                     </li>
                     <li>
                        <a href="#tab5">How do I receive content from approved speakers?</a>
                     </li>                 
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                     
                     <li>
                        <a href="#tab6">Can I add special comments about each speaker?</a>
                     </li>   
                        <li>
                        <a href="#tab7">Is there  a one page summary of each speaker?</a>
                     </li>
                     <li>
                        <a href="#tab8">Can a speaker be listed in multiple sessions?</a>
                     </li>
                     <li>
                        <a href="#tab9">Can I send emails to all speakers at a time?</a>
                     </li> 

                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">How can I ask for missing information from speakers?</h2>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="add-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/missing-information.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p  class="tags1">Click on the 'Request' icon against speaker names in the ‘Manage Speakers’ section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/missing-information1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p  class="tags1">In the pop-up that comes up, you can choose to request them for missing information or missing documentation. Select the fields/documents you require them to provide.</p>
                       <p>You have the option to copy the speaker manager and schedule the email. There is a field where you can type in a message to send across to the speaker.</p>
                     </div>
                  </div>
               </div>
             
              
                
             
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="add-user1" data-toggle="tab" href="#add-user1" role="tab" aria-controls="add-user1" aria-selected="true"> <img src="images/missing-information.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li> 
                  <li class="nav-item">
                     <a class="nav-link" id="add-user2" data-toggle="tab" href="#add-user2" role="tab" aria-controls="add-user2" aria-selected="false"><img src="images/missing-information1.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">Can I send emails to individial speakers?</h2>
            
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/email.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">Yes, you can. Click on the 'Bell' icon against the speaker names in the ‘Manage Speakers’ section. This will open up a form.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="manage-user11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/email1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags11">The form has fields for ‘Email subject’, ‘Speaker Manager Email’ and ‘CC Email Addresses’. You can select an email template from the available templates.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/email.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="manage-user11" data-toggle="tab" href="#manage-user11" role="tab" aria-controls="manage-user11" aria-selected="true"> <img src="images/email.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">How can I manage all the emails sent to each speaker?</h2>
           
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">In the ‘Manage Speakers’ section, there is a column titled ‘Emails sent’. Under this column, you can click on the ‘Preview’ button against a speaker and view all the emails that were sent to the speaker.</p>
                     </div>
                  </div>
               </div>
                 <div class="tab-pane masonry-container	" id="plan1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags1">Here you can view all the emails that were sent to the speaker.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/manage-email.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#plan1" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/manage-email1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">How do I know if a speaker opened my emails?</h2>
            
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p class="tags1">In the ‘Manage Speakers’ section, there is a column titled ‘Emails sent’. Under this column, click on the ‘Preview’ button against a speaker.</p>
                      
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/manage-email1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p class="tags1">Here you can view the date on which the emails were sent and whether the speaker has opened them or not.</p>
                      
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab5" role="tablist">
                 <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#change-plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/manage-email.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="plan1" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/manage-email1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">How do I receive content from approved speakers?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/recive-content.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags11">Within the application form for a speaker, there is space allotted for the speakers to upload their documents. If they haven’t uploaded any content there, then you may request content from these speakers.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="track-history11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/recive-content1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags11">Click on the 'Request' icon against the speaker names in the ‘Manage Speakers’ section.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="track-history12" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/recive-content2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags11">You can requests the approved speakers to share the required content.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history1" data-toggle="tab" href="#track-history1" role="tab" aria-controls="track-history1" aria-selected="true"> <img src="images/recive-content.jpg" class="img-fluid" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="track-history11" data-toggle="tab" href="#track-history11" role="tab" aria-controls="track-history11" aria-selected="true"> <img src="images/recive-content1.jpg" class="img-fluid" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="track-history12" data-toggle="tab" href="#track-history12" role="tab" aria-controls="track-history12" aria-selected="true"> <img src="images/recive-content2.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6">
         <div class="container">
            <h2 class="mb-4">Can I add special comments about each speaker?</h2>
            <p>Yes, you can, in the 'Notes' field at the bottom of the page where you edit the speaker information. Here you can enter comments about the speaker. The note entered here can be viewed by clicking the ‘View’ icon against for the specific speaker.</p>
        
         </div>
      </section>   
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab7">
         <div class="container">
            <h2 class="mb-4">Is there  a one page summary of each speaker?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-histor10" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/summary.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags11">Within the speaker application form, there are fields titled ‘Quote’ and ‘Bio’. The speaker can fill these out. </p>
                      <p>In case the speaker has not, you can fill in these fields by editing the speaker’s information.</p>
                      <p>Click on the 'Edit' icon to edit the speaker’s information. You can add the quote and bio there.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="track-histor12" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/summary1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags11">When you click on ‘View’, you will be able to see the content within these two fields.</p>
                     </div>
                  </div>
               </div>
               
                
                
               <ul class="nav nav-tabs" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-histor10" data-toggle="tab" href="#track-histor10" role="tab" aria-controls="track-histor10" aria-selected="true"> <img src="images/summary.jpg" class="img-fluid" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="track-histor12" data-toggle="tab" href="#track-histor12" role="tab" aria-controls="track-histor12" aria-selected="true"> <img src="images/summary1.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab8">
         <div class="container">
            <h2 class="mb-4">Can a speaker be listed in multiple sessions?</h2>
           
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="multiple-sessions1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-sessions.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Yes, they can be. </p>
                      <p>In the drop-down under ‘Speakers’ on the left panel, there is an option ‘Event Agenda’.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="multiple-sessions2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-sessions1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">You can assign speakers against each point in the agenda. A speaker can be assigned to multiple sessions on the agenda. </p>
                      <p>Click on the 'Manage' icon next to the event.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="multiple-sessions3" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-sessions2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Click on 'Edit' to add speakers.</p>
                     </div>
                  </div>
               </div>
                <div class="tab-pane masonry-container " id="multiple-sessions4" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-sessions3.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Click on ‘Add Speakers’.</p>
                     </div>
                  </div>
               </div>
                <div class="tab-pane masonry-container " id="multiple-sessions5" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/multiple-sessions4.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Select the speaker from the list to add a speaker to the session. </p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="multiple-sessions1" data-toggle="tab" href="#multiple-sessions1" role="tab" aria-controls="multiple-sessions1" aria-selected="true"> <img src="images/recive-content.jpg" class="img-fluid mb-" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="multiple-sessions2" data-toggle="tab" href="#multiple-sessions2" role="tab" aria-controls="multiple-sessions2" aria-selected="true"> <img src="images/recive-content1.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="multiple-sessions3" data-toggle="tab" href="#multiple-sessions3" role="tab" aria-controls="multiple-sessions3" aria-selected="true"> <img src="images/recive-content2.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="multiple-sessions4" data-toggle="tab" href="#multiple-sessions4" role="tab" aria-controls="multiple-sessions4" aria-selected="true"> <img src="images/recive-content2.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="multiple-sessions5" data-toggle="tab" href="#multiple-sessions5" role="tab" aria-controls="multiple-sessions5" aria-selected="true"> <img src="images/recive-content2.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab9" style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">Can I send emails to all speakers at a time?</h2>
           
            <div class="tab-content" id="myTabContentsa5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="all-speakers1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/all-speakers.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Yes, you can. </p>
                      <p>In the drop-down under ‘Speakers’, click on ‘Bulk Notify’.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="all-speakers2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/all-speakers1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">Here you can select the speakers you would want the bulk email to reach. You can select speakers according to their status. </p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="all-speakers3" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/all-speakers2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">You can select speakers according to their speaker type.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container " id="all-speakers4" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/all-speakers3.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                      <p class="tags">You can select speakers individually as well. </p>
                      <p>Select a template that matches your requirement and add a subject line.</p>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs" id="myTabsa6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="all-speakers1" data-toggle="tab" href="#all-speakers1" role="tab" aria-controls="all-speakers1" aria-selected="true"> <img src="images/all-speakers.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="all-speakers2" data-toggle="tab" href="#all-speakers2" role="tab" aria-controls="all-speakers2" aria-selected="true"> <img src="images/all-speakers1.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                 <li class="nav-item">
                     <a class="nav-link " id="all-speakers3" data-toggle="tab" href="#all-speakers3" role="tab" aria-controls="all-speakers3" aria-selected="true"> <img src="images/all-speakers2.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="all-speakers4" data-toggle="tab" href="#all-speakers4" role="tab" aria-controls="all-speakers4" aria-selected="true"> <img src="images/all-speakers3.jpg" class="img-fluid mb-4" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection"  style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Communication</h3>
                           <p>Engage in quick and easy communication with your sponsors.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="sponsor-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/mail.svg" class="img-fluid mt-3 mb-4 mb-md-0 " width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Management</h3>
                           <p>Manage all your sponsors for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays" >
                  <a href="master-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Communication</h3>
                           <p>Engage in quick and easy communication with all your contacts.</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  