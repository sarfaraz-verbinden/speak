<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="There are five dashboards on Speaker Engage - Account Dashboard, Event Dashboard, Speaker Dashboard, Sponsor Dashboard, and Master Dashboard. All these dashboards present the high-level data on the activities within an account and event.">
      <title>Dashboards available on Speaker Engage | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboards</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Dashboards</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">What types of dashboards are available for me?</a>
                     </li>
                     <li>
                        <a href="#tab2">What information is available in my Account Dashboard?</a>
                     </li>
                     <li>
                        <a href="#tab3">What information is available in my Event Dashboard?</a>
                     </li>                    
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab4">What information is available in my Speaker Dashboard?
                        </a>
                     </li>
                     <li>
                        <a href="#tab5">What information is available in my Sponsor Dashboard?</a>
                     </li>
                     <li>
                        <a href="#tab6">What information is available in my Master Dashboard?</a>
                     </li>                    
                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">What types of dashboards are available for me?</h2>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="add-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/account-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p class="tags mt-3 mt-md-0"> For each account, there are 5 different dashboards. </p>
                        <ul class="list-none">
                           <li><strong>1. Account Dashboard:</strong> This dashboard summarizes key metrics of your account which include accurate numbers of events, speakers,  sponsors, emails sent, hours saved, and many others.</li>
                          
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/event-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <ul class="list-none">
                           <p class="tags d-block d-md-none"></p>
                           <li ><strong>2. Event Dashboard:</strong> This dashboard is specific to each event and summarizes key metrics for that event. Additional information is also summarized for a quick view of the event status.</li>
                          
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user3" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/speaker-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                           <p class="tags d-block d-md-none"></p>
                            <li  ><strong>3. Speaker Dashboard:</strong> This dashboard provides key metrics related to the Speaker section of your event. You also can view the latest communications sent and their performance as well as gaps in profiles.</li>
                           </ul>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user4" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sponsor-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                            <p class="tags d-block d-md-none"></p>
                           <li ><strong>4. Sponsor Dashboard:</strong> This dashboard provides key metrics related to the Sponsor section of your event. You also can view the latest communications sent and their performance as well as gaps in profiles.</li></ul>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade masonry-container" id="add-user5" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                          <p class="tags d-block d-md-none"></p>
                           <li  ><strong>5. Master Dashboard:</strong> This dashboard provides key metrics related to the Master section of your event. You also can view the latest communications sent and their performance as well as gaps in profiles.</li></ul>
                     </div>
                  </div>
               </div>
             
               <ul class="nav nav-tabs" id="myTab2" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="add-user1" data-toggle="tab" href="#add-user1" role="tab" aria-controls="add-user1" aria-selected="true"> <img src="images/account-dashboard.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="add-user2" data-toggle="tab" href="#add-user2" role="tab" aria-controls="add-user2" aria-selected="false"><img src="images/event-dashboard.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="add-user3" data-toggle="tab" href="#add-user3" role="tab" aria-controls="add-user3" aria-selected="false"><img src="images/speaker-dashboard.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                   <li class="nav-item">
                     <a class="nav-link" id="add-user4" data-toggle="tab" href="#add-user4" role="tab" aria-controls="add-user4" aria-selected="false"><img src="images/sponsor-dashboard.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                   <li class="nav-item">
                     <a class="nav-link" id="add-user5" data-toggle="tab" href="#add-user5" role="tab" aria-controls="add-user5" aria-selected="false"><img src="images/master-dashboard.jpg" class="img-fluid mb-4 mb-md-0" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">What information is available in my Account Dashboard?</h2>
             <p>The account dashboard gives you a top-level comprehensive list of all the information related to your account. This provides a quick overview or your overall event status. This includes information on the total number of:</p>
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/account-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                         
                           <ul class="list-none">
                              <li>1. Active Events</li>
                              <li>2. Speakers in your account (from all events)</li>
                              <li>3. Sponsors in your account (from all events)</li>
                              <li>4. Emails sent from your account to-date</li>
                              <li>5. Time saved by using the Speaker Engage Solution</li>
                              <li>6. Contacts in your account (from all events)</li>
                              <li>7. Storage used in your account (from all events)</li>
                              <li>8. Emails sent suring the current month</li>
                           </ul>
                        
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/account-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">What information is available in my Event Dashboard?</h2>
            <p>Each event has its own dashboard so you can get a quick assessment on the state of your event. The information provided is:</p>
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/event-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                        <ul class="list-none">
                           <li>1. Event infromation (name, date and location)</li>
                           <li>2. Event external pages: provides you quick access to the available external pages and their URLs.</li>
                           <li>3. Quick actions are links to give you a faster navigation to the most frequently used action items.</li>
                           <li>4. Speaker, sponsor, and master dashboards: These are static dashboards aggregated to give you a glimpse of the status of your event.</li>
                        </ul>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/event-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">What information is available in my Speaker Dashboard?</h2>
            <p>The Speaker Dashboard gives you at-a-glance information pertaining to speaker management. The top portion of the dashborad is a quick summary of all information. You can also review speaker allocation based on their role. There is also a list of recent scheduled and sent emails. The bottom part of the dashboard is a summary of profile gaps of the speakers associated to this event:</p>
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/speaker-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                           <li>1. Speaker status (approved, declined, and in contract)</li>
                           <li>2. Emails sent/opened</li>
                           <li>3. Influencer classification</li>
                           <li>4. Speaking opportunity classification</li>
                           <li>5. Recent and scheduled communications</li>
                           <li>6. Missing profile information</li>
                        </ul>
                      
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs d-none d-md-block" id="myTab5" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="change-plan11" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="change-plan11" aria-selected="true"> <img src="images/speaker-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">What information is available in my Sponsor Dashboard?</h2>
            <p>The sponsor dashboard gives you at-a-glance information pertaining to sponsor management. The top portion of the dashborad is a quick summary of all information. You can also review sponsor status based on their role. There is also a list of recent scheduled and sent emails. The bottom part of the dashboard is a summary of profile gaps of the sponsors associated to this event:</p>
            <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sponsor-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                        <ul class="list-none">
                           <li>1. Sponsor status (secured, not ready, and in the pipeline)</li>
                           <li>2. Emails sent/opened</li>
                           <li>3. Potential funding</li>
                           <li>4. Committed funding</li>
                           <li>5. Sponsor opportunity classification</li>
                           <li>6. Recent and scheduled communications</li>
                           <li>7. Missing profile information</li>
                        </ul>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history1" data-toggle="tab" href="#track-history1" role="tab" aria-controls="track-history1" aria-selected="true"> <img src="images/sponsor-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6" style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">What information is available in my Master Dashboard?</h2>
            <p>The master list is the overall contact list that you can use for all your communication. The Master Dashboard gives a view of the master list and includes information on:</p>
         <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/master-dashboard.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                           <li>1. Total contacts</li>
                           <li>2. Emails sent/opened</li>
                           <li>3. Master opportunity classification</li>
                           <li>4. Recent and scheduled communications</li>
                           <li>5. Missing profile information</li>
                        </ul>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history2" data-toggle="tab" href="#track-history2" role="tab" aria-controls="track-history2" aria-selected="true"> <img src="images/master-dashboard.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
         </div>
      </section>   
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection" style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor.svg" class="img-fluid  mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Management</h3>
                           <p>Manage all your sponsors for an event.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="event-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/mail.svg" class="img-fluid mt-2 mb-4 mb-md-0 " width="50px" height="50px" style="">
                        </div>
                        <div class="col-md-10">
                           <h3>Event Management</h3>
                           <p>Manage all your events seamlessly. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays" >
                  <a href="master-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master.svg" class="img-fluid  mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Management</h3>
                           <p>Manage all the contacts you need for an event. 
</p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">// ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  