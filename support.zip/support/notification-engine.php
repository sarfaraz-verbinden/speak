<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Get a glimpse of everything you will be notified on | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Notification Engine</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Notification Engine</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">What emails can I expect for account related activity?</a>
                     </li>
                     <li>
                        <a href="#tab2">What emails can I expect for billing related acticity?</a>
                     </li>
                                     
                  </ul>
               </div> 
               <div class="col-lg-6">
                  <ul class="question-list">
                    
                     <li>
                        <a href="#tab3">Is there a daily report activity that is sent?</a>
                     </li>
                     <li>
                        <a href="#tab4">What alerts are integrated in the platform?                        </a>
                     </li>                    
                  </ul>
               </div> 
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">What emails can I expect for account related activity?</h2>
            <p>You will receive emails when you sign up for an account.  In addition you will also receive account related communication when certain limits are being reached. These emails are only sent to users who are classified as Admin.</p>           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">What emails can I expect for billing related acticity?</h2>
             <p>You will receive emails related to your subscription along with reminders on when the free trial period is ending or the term of your subscription is ending.</p>           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">Is there a daily report activity that is sent?</h2>
           <p>Yes, there is a daily report email that is sent to all users that summarizes the status of each event. This allows you to take micro action as the event organizer or as an event contributor.</p>           
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4"  style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">What alerts are integrated in the platform?</h2>
           <p>There are several types of alerts that are integrated in the system. One significant alert is sent when someone downloads the contact list.  This allows the admins to manage expectations and set the right policies.</p>
         </div>
      </section>
     
       
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection"  style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="action-tracker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/action.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Action Tracker</h3>
                           <p>Track your actions and manage your events more efficiently.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="dashboard.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/dashboard.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Dashboard</h3>
                           <p>Navigate through your array of dashboards.</p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="resource-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/resource.svg" class="img-fluid mt-3 mb-4 mb-md-0 ">
                        </div>
                        <div class="col-md-10">
                           <h3>Resource Management</h3>
                           <p>Aggregate and store all assets and resources related to an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/comment.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  