<?php include("../include/html_codes.php"); ?>
<!DOCTYPE html>
<html  >
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.10.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="../images/favicon.ico">
      <meta name="description" content="">
      <title>Manage all your sponsors for an event | Speaker Engage</title>
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons2/mobirise2.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/web/assets/mobirise-icons/mobirise-icons.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/tether/tether.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-grid.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/bootstrap/css/bootstrap-reboot.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/formstyler/jquery.formstyler.theme.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/datepicker/jquery.datetimepicker.min.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/dropdown/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/socicon/css/styles.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/theme/css/style.css">
      <link rel="stylesheet" href="../assets/mainpage/assets3/mobirise/css/mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="mbr-additional.css" type="text/css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" />
      <style type="text/css">
         body {
         padding-right: 0px !important;
         }
         .pl-0 li {
         padding-left: 0px !important;
         }
         .powerede-by {
         text-align: center;
         padding-top: 20px;
         border-top: 1px solid rgba(255,255,255,0.1);
         font-size: 14px;
         background: #343351;
         padding-bottom: 20px;
         margin-bottom: 0;
         color: #fff;
         }
         input[type=checkbox]
         {
         /* Double-sized Checkboxes */
         -ms-transform: scale(1.2); /* IE */
         -moz-transform: scale(1.2); /* FF */
         -webkit-transform: scale(1.2); /* Safari and Chrome */
         -o-transform: scale(1.2); /* Opera */
         padding: 10px;
         }
         .form-check-inline {
         margin-right: 0px;
         width: 33%;
         margin-bottom: 10px;
         }
         form label {
         display: inline-block;
         width: 100px;
         }
         form div {
         margin-bottom: 10px;
         }
         .error {
         color: red;
         margin-left: 5px;
         }
         label.error {
         display: inline;
         }
         h4 {
         font-weight: 400;
         line-height: 29px;
         margin-bottom: 15px;
         }
         .cid-rH8MDyvHtG h1 {
         color: #5580ff;
         font-weight: 600;
         padding-bottom: 0px;
         }
         .has_error {
         color: #cc0033;
         display: inline-block;
         background-color: #fce4e4;
         border: 1px solid #cc0033;
         outline: none;
         }
         @media (max-width: 991px){
         .plan-descr.mbr-fonts-style, .mbr-section-btn {
         text-align: center !important;
         }
         .cid-rHBCmoWF1E .plan .list-group-item {
         padding-right: 0px !important;
         padding-left: 0px !important;
         }
         .mx-5.enter {
         margin-left: 1rem !important;
         margin-right: 1rem !important;
         }
         }
      </style>
   </head>
   <body>
    <?php echo landing_header(); 
       echo support_header();?>
      <section class="fshadow">
         <div class="container">
            <nav aria-label="breadcrumb" >
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="index.php">Speaker Engage Support</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Sponsor Management</li>
               </ol>
            </nav>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow">
         <div class="container">
            <h1 class="mbr-bold mb-4">Sponsor Management</h1>
            <div class="row">
               <div class="col-lg-6">
                  <ul class="question-list">
                     <li>
                        <a href="#tab1">What is the purpose of Sponsor Management?</a>
                     </li>
                     <li>
                        <a href="#tab2">How can I add new sponsors to my list?</a>
                     </li>
                     <li>
                        <a href="#tab3">Can I create custom categories to classify sponsors?</a>
                     </li>  
                     <li>
                        <a href="#tab4">Can I create types of sponsorships that I offer for my event?
                        </a>
                     </li>                  
                  </ul>
               </div>
               <div class="col-lg-6">
                  <ul class="question-list">
                     
                     <li>
                        <a href="#tab5">Can I create customized categories and sponsorship types for each event?</a>
                     </li>
                     <li>
                        <a href="#tab6">Is there a dashboard to get a quick update on the status regarding sponsorships?</a>
                     </li>                    
                  </ul>
               </div>
            </div>
         </div>
      </section>
       
     
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab1">
         <div class="container">
            <h2 class="mb-4">What is the purpose of Sponsor Management?</h2>
           <p>Sponsors are very critical to any event. Communicating with them and providing them information in a timely manner is crucial to your long term relationship with them. This section of the Speaker Engage enables you to organize every aspect of sponsor management and communication. In this section you can create an inventory of sponsor packages available, the overall budget, the status of each sponsor, and all the communication that was sent to them. You can also create standard and customized communication specific to sponsors.</p>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab2">
         <div class="container">
            <h2 class="mb-4">How can I add new sponsors to my list?</h2>
             
            <!-- tab content starts here -->
            <div class="tab-content" id="myTabContent2">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="manage-user1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/new-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                         <p class="tags1">To add a new sponsor to your list, follow these three steps: </p>
                         <p>Step 1: Click on 'Create New' from the 'Manage Sponsors' section.</p>
                        
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="manage-user11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/new-sponsor1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                         <p class="tags1">Step 2: Click on 'Create New' from the pop-up screen. </p>
                        
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="manage-user12" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/new-sponsor2.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        
                         <p  class="tags1">Step 3: Fill in the mandatory details and any additional information you may have. Click on 'Save'.</p>
                         <p>You do not need all the information to fill at this time, only the mandatory fields. You can request for additional information with the 'Request' feature.</p>
                        
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab3" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="manage-user1" data-toggle="tab" href="#manage-user1" role="tab" aria-controls="manage-user1" aria-selected="true"> <img src="images/new-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                   <li class="nav-item">
                     <a class="nav-link " id="manage-user11" data-toggle="tab" href="#manage-user11" role="tab" aria-controls="manage-user11" aria-selected="true"> <img src="images/new-sponsor1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="manage-user12" data-toggle="tab" href="#manage-user12" role="tab" aria-controls="manage-user12" aria-selected="true"> <img src="images/new-sponsor2.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab3">
         <div class="container">
            <h2 class="mb-4">Can I create custom categories to classify sponsors?</h2>            
            <div class="tab-content" id="myTabContent3">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="plan" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sponsor-categories.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p  class="tags1">Yes, you can.  There are default categories such as 'Sponsors Secured', 'Sponsors Not Ready', and 'Sponsors In-pipeline'. </p>
                       <p>Step 1: To create a new category, click on 'Create New Status'.</p>
                     </div>
                  </div>
               </div>
               <div class="tab-pane masonry-container" id="plan1" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sponsor-categories1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                       <p  class="tags1">Step 2:Fill in the information and save. Now you can associate a sponsor with this newly created category.</p>
                     </div>
                  </div>
               </div>
                
               <ul class="nav nav-tabs" id="myTab4" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="plan" data-toggle="tab" href="#plan" role="tab" aria-controls="plan" aria-selected="true"> <img src="images/sponsor-categories.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" id="plan1" data-toggle="tab" href="#plan1" role="tab" aria-controls="plan1" aria-selected="true"> <img src="images/sponsor-categories1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab4">
         <div class="container">
            <h2 class="mb-4">Can I create types of sponsorships that I offer for my event?</h2>
            
            <div class="tab-content" id="myTabContent4">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="change-plan11" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/type-sponsor.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p  class="tags1">Yes, you can. Step1: Within the Sponsor tab on the left, there is a section titled 'Type Settings'.</p>
                      
                     </div>
                  </div>
               </div>
                <div class="tab-pane masonry-container " id="change-plan12" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/type-sponsor1.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <p  class="tags1">Step 2: Here you can choose to create a specific sponsorship package in addition to the default options. When you create a new sponsorship type, you can also add the number of sponsorships available under this category and the sponsorship amount. This will create the total opportunities in the dashboard.</p>
                      
                     </div>
                  </div>
               </div>
               <ul class="nav nav-tabs" id="myTab5" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="change-plan11" data-toggle="tab" href="#change-plan11" role="tab" aria-controls="change-plan11" aria-selected="true"> <img src="images/type-sponsor.jpg" class="img-fluid" width="100"></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link " id="change-plan12" data-toggle="tab" href="#change-plan12" role="tab" aria-controls="change-plan12" aria-selected="true"> <img src="images/type-sponsor1.jpg" class="img-fluid" width="100"></a>
                  </li>
                  
               </ul>
            </div>
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab5">
         <div class="container">
            <h2 class="mb-4">Can I create customized categories and sponsorship types for each event?</h2>
             <p>Yes, you can. For each event, you can create customized classifications/categories for each sponsor. You can also create customized sponsorship packages available for each event. This allows you to learn from each event and build on sponsor and sponsorship strategies.</p>
            
         </div>
      </section>
      <section class="cid-rHBCmoWF1E fshadow pt-4 pb-4" id="tab6"  style="box-shadow: none;">
         <div class="container">
            <h2 class="mb-4">Is there a dashboard to get a quick update on the status regarding sponsorships?</h2>
            <p>The Sponsor Dashboard gives you at-a-glance information pertaining to sponsor management. The top portion of the dashborad is a quick summary of all information. You can also review sponsor status based on their role. There is also a list of recent scheduled and sent emails. The bottom part of the dashboard is a summary of profile gaps of the sponsors associated to this event:</p>
         <div class="tab-content" id="myTabContent5">
               <!-- content 1 -->
               <div class="tab-pane masonry-container fade show active" id="track-history2" role="tabpanel" >
                  <div class="row">
                     <div class="col-lg-6">
                        <img src="images/sporsorship.jpg" class="img-fluid mb-4">
                     </div>
                     <div class="col-lg-6">
                        <ul class="list-none">
                           <li>1. Sponsor status (secured, not ready, and in pipeline)</li>
                           <li>2. Emails sent/opened</li>
                           <li>3. Potential funding</li>
                           <li>4. Committed funding</li>
                           <li>5. Sponsor opportunity classification</li>
                           <li>6. Recent and scheduled communications</li>
                           <li>7. Missing profile information</li>
                        </ul>
                     </div>
                  </div>
               </div>
                
                
               <ul class="nav nav-tabs d-none d-md-block" id="myTab6" role="tablist">
                  <li class="nav-item">
                     <a class="nav-link active" id="track-history2" data-toggle="tab" href="#track-history2" role="tab" aria-controls="track-history2" aria-selected="true"> <img src="images/sporsorship.jpg" class="img-fluid" width="100"></a>
                  </li>
                 
                  
               </ul>
            </div>
         </div>
      </section>   
      
      <section style="background: #5580ff;">
         <div class="container align-center pt-4 pb-4">
            <h2 class="text-white">Related Content</h2>
         </div>
      </section>
      <section class="fshadow pt-4 pb-4 bottomsection" style="box-shadow: none;">
         <div class="container">
            <div class="row">
               <div class="col-md-6 p-4" style="background: #F9F9F9">
                  <a href="speaker.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/speaker.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Speaker Management</h3>
                           <p>Manage your growing list of speakers for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4">
                  <a href="sponsor-communication.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/sponsor-communication.svg" class="img-fluid mt-3 mb-4 mb-md-0" width="50px" height="50px">
                        </div>
                        <div class="col-md-10">
                           <h3>Sponsor Communication</h3>
                           <p>Engage in quick and easy communication with your sponsors. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays1" >
                  <a href="event-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/mail.svg" class="img-fluid mt-3 mb-4 mb-md-0 ">
                        </div>
                        <div class="col-md-10">
                           <h3>Event Management</h3>
                           <p>Manage all your events seamlessly. </p>
                        </div>
                     </div>
                  </a>
               </div>
               <div class="col-md-6 p-4 bg-grays">
                  <a href="master-management.php">
                     <div class="row">
                        <div class="col-md-2 align-center">
                           <img src="images/master.svg" class="img-fluid mt-3 mb-4 mb-md-0">
                        </div>
                        <div class="col-md-10">
                           <h3>Master Management</h3>
                           <p>Manage all the contacts you need for an event. </p>
                        </div>
                     </div>
                  </a>
               </div>
            </div>
         </div>
      </section>
      <?php echo landing_footer(); ?>
      <script src="../assets/mainpage/assets/web/assets/jquery/jquery.min.js"></script>
      <script src="../assets/formpage/assets/popper/popper.min.js"></script>
      <script src="../assets/formpage/assets/tether/tether.min.js"></script>
      <script src="../assets/formpage/assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.js"></script>
      <script src="../assets/formpage/assets/formstyler/jquery.formstyler.min.js"></script>
      <script src="../assets/formpage/assets/datepicker/jquery.datetimepicker.full.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/nav-dropdown.js"></script>
      <script src="../assets/formpage/assets/dropdown/js/navbar-dropdown.js"></script>
      <script src="../assets/formpage/assets/touchswipe/jquery.touch-swipe.min.js"></script>
      <script src="../assets/formpage/assets/smoothscroll/smooth-scroll.js"></script>
      <script src="../assets/formpage/assets/theme/js/script.js"></script>
      <script src="../assets/formpage/assets/formoid/formoid.min.js"></script>
      <script type="text/javascript">
         // ===== Scroll to Top ==== 
$(window).scroll(function() {
    if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
        $('#return-to-top').fadeIn(200);    // Fade in the arrow
    } else {
        $('#return-to-top').fadeOut(200);   // Else fade out the arrow
    }
});
$('#return-to-top').click(function() {      // When arrow is clicked
    $('body,html').animate({
        scrollTop : 0                       // Scroll to top of body
    }, 500);
});
  </script>
   </body>
</html>  